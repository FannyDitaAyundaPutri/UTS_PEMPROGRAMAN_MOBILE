package com.example.cupcake_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
