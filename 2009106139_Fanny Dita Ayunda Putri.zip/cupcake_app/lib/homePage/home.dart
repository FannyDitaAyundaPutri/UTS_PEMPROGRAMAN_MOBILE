import 'package:cupcake_app/Login/login.dart';
import 'package:cupcake_app/Utils/beranda.dart';
import 'package:cupcake_app/Utils/profile.dart';
import 'package:cupcake_app/main.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  List<BottomNavigationBarItem> navbarItem = [
    const BottomNavigationBarItem(
        icon: Icon(Icons.assignment),
        label: "Beranda",
        backgroundColor: Colors.amber),
    const BottomNavigationBarItem(
        icon: Icon(Icons.person),
        label: "Profile",
        backgroundColor: Colors.amber),
  ];

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int _index = 0;
  final List<Widget> _body = [
    const beranda(),
    const profile(
      email: '',
      password: '',
    )
  ];

  @override
  Widget build(BuildContext context) {
    final themeMode = Provider.of<DarkMode>(context);
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        actions: [
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(right: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Hallo, ',
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Atma',
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      ' Fanny ',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontFamily: "Montserrat",
                          fontSize: 10),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(right: 10),
                child: CircleAvatar(
                  backgroundImage: AssetImage('Images/fannyprofile.jpg'),
                  radius: 20,
                ),
              ),
            ],
          ),
        ],
        backgroundColor: Colors.amber,
        title: const Text(
          'CupCakes App',
          style: TextStyle(color: Colors.black, fontFamily: 'Acme'),
        ),
      ),


      //DRAWER
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                  gradient: RadialGradient(radius: 2.0, colors: <Color>[
                Colors.amber.shade400,
                Colors.amber.shade100,
              ])),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const <Widget>[
                  // ImageIcon(
                  //   AssetImage('Images/profile.jpg'),
                  //   size: 100,
                  // ),
                  CircleAvatar(
                    backgroundImage: AssetImage('Images/fannyprofile.jpg'),
                    radius: 50,
                  ),
                  Text(
                    "Fanny Dita Ayunda Putri",
                    style: TextStyle(
                        fontSize: 18,
                        fontFamily: 'Fjalla',
                        wordSpacing: 1,
                        inherit: false),
                  )
                ],
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.person_outline,
                color: Colors.grey,
              ),
              title: const Text(
                "Profile",
                style: TextStyle(color: Colors.grey),
              ),
              subtitle: const Text(
                "profile",
                style: TextStyle(color: Colors.grey),
              ),
              tileColor: Colors.white,
              onTap: () {
                _scaffoldKey.currentState!.openEndDrawer();
                setState(() {
                  _index = 1;
                });
              },
            ),
            ListTile(
              leading: const Icon(Icons.dark_mode, size: 35),
              title: const Text(
                "Tema",
                style: TextStyle(color: Colors.grey),
              ),
              subtitle: const Text(
                "mengatur tema aplikasi",
                style: TextStyle(color: Colors.grey),
              ),
              trailing: Switch(
                value: themeMode.darkMode,
                activeTrackColor: const Color.fromARGB(255, 89, 216, 255),
                activeColor: Colors.amber.shade900,
                onChanged: (value) {
                  themeMode.changeMode();
                },
              ),
              tileColor: Colors.white,
            ),
            ListTile(
              leading: const Icon(
                Icons.logout,
                color: Colors.grey,
              ),
              title: const Text(
                "Keluar",
                style: TextStyle(color: Colors.grey),
              ),
              subtitle: const Text(
                "Keluar dari Aplikasi",
                style: TextStyle(color: Colors.grey),
              ),
              tileColor: Colors.white,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) {
                    return const login();
                  }),
                );
              },
            ),
          ],
        ),
      ),
      body: _body.elementAt(_index),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.amber,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        items: navbarItem,
        currentIndex: _index,
        onTap: (i) {
          setState(() {
            _index = i;
          });
        },
      ),
    );
  }
}
