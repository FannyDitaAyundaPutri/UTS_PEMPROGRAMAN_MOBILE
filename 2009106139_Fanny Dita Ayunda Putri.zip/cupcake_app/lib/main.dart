import 'package:cupcake_app/splashScreen/splashScreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
      ChangeNotifierProvider(create: (context) => DarkMode(), child: MyApp()));
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);
  var mainTheme = ThemeData.light();
  var darkTheme = ThemeData.dark();

  @override
  Widget build(BuildContext context) {
    final themeMode = Provider.of<DarkMode>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const splashScreen(),
      theme: themeMode.darkMode ? mainTheme : darkTheme,
    );
  }
}

class DarkMode with ChangeNotifier {
  bool darkMode = true;
  changeMode() {
    darkMode = !darkMode;
    notifyListeners();
  }
}
