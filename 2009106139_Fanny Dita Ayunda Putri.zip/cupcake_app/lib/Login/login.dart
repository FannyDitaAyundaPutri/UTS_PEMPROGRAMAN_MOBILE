import 'package:cupcake_app/Utils/profile.dart';
import 'package:cupcake_app/homePage/home.dart';
import 'package:flutter/material.dart';

// ignore: non_constant_identifier_names
List<user> User = [];

class user {
  String email, password;
  user({
    required this.email,
    required this.password,
    // required this.type
  });
}

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  final _formKey = GlobalKey<FormState>();

  final ctrlEmail = TextEditingController();
  final ctrlPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Scaffold(
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 255, 222, 89),
          ),

          //LIST VIEW
          child: ListView(
            children: [
              Container(
                height: 220,
                width: 220,
                margin: EdgeInsets.only(top: 120),
                child: Image(
                  image: AssetImage('images/logoFanny.png'),
                ),
              ),
              Container(
                padding: EdgeInsets.only(left: 20, right: 20),
                child: TextFormField(
                  controller: ctrlEmail,
                  cursorColor: Color.fromARGB(255, 176, 205, 176),
                  maxLines: 1,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(color: Colors.transparent)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    hintText: "Email",
                    prefixIcon: Icon(
                      Icons.people,
                      color: Color.fromARGB(255, 114, 111, 111),
                    ),
                    fillColor: Colors.white.withOpacity(0.3),
                    filled: true,
                  ),
                  validator: (value) =>
                      value!.isEmpty ? 'Email tidak boleh kosong !' : null,
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 30, left: 20, right: 20),
                child: TextFormField(
                  controller: ctrlPassword,
                  cursorColor: Color.fromARGB(255, 176, 205, 176),
                  maxLines: 1,
                  decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(color: Colors.transparent)),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    hintText: "Password",
                    prefixIcon: Icon(
                      Icons.people,
                      color: Color.fromARGB(255, 114, 111, 111),
                    ),
                    fillColor: Colors.white.withOpacity(0.3),
                    filled: true,
                  ),
                  validator: (value) =>
                      value!.isEmpty ? 'Password tidak boleh kosong !' : null,
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 10, left: 20, right: 20),
                height: 50,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.amber.shade800,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => profile(
                                email: ctrlEmail.text,
                                password: ctrlPassword.text),
                          ));
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => home()));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please fill input')),
                      );
                    }
                  },

                  child: Text(
                    "LOGIN",
                    style: TextStyle(
                      color: Colors.grey.shade200,
                      // fontFamily: 'Montserrat',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
